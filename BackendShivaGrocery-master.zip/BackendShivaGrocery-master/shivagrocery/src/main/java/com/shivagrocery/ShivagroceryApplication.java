package com.shivagrocery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShivagroceryApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShivagroceryApplication.class, args);
	}

}
